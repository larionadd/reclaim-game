RECLAIM 0.1 — release bundle

Android: install Android/RECLAIM-v0.1-debug.apk. This is a debug-signed APK.
Web: the game files are at the ZIP root. Serve this folder with a local HTTP
server, then open its address in a browser. For example, if Python is installed:
    python -m http.server 8000
    http://localhost:8000/
Opening index.html directly as a file may be blocked by browser module security.
Online version: https://larionadd.github.io/reclaim-game/

Language can be selected on the title screen: English, Ukrainian, or Russian.
Save data stays in the browser or Android app on the user's device.
